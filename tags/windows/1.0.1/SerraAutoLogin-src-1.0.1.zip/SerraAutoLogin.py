#	Copyright (c) 2014, Andrea Esposito <info@andreaesposito.org>
#	All rights reserved.
#
#	Redistribution and use in source and binary forms, with or without
#	modification, are permitted provided that the following conditions are met:
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#    * Neither the name of the Andrea Esposito nor the
#      names of its contributors may be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
#	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
#	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#	DISCLAIMED. IN NO EVENT SHALL Andrea Esposito BE LIABLE FOR ANY
#	DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
#	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
#	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
#	ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
#	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

if __name__ == '__main__':
	import SysTrayIcon
	import easygui
	import configparser
	import threading
	import socket
	import requests
	import re
	import base64
	import Vigenere
	import LogManager
	import webbrowser
	
	icon = 'icon/SerraAutoLogin.ico'
	hover_text = "SerraAutoLogin"
	
	LogManager.createLog()
	
	LogManager.log("Reading Config file...")
	config = configparser.ConfigParser()
	config.read('config.ini')
	username = config.get('SerraAutoLogin', 'Username')
	password = Vigenere.decryptMessage("NoobTest", config.get('SerraAutoLogin', 'cryptedpassword'))
	url = config.get('SerraAutoLogin', 'Url')
	loginAtStartup = config.get('SerraAutoLogin', 'loginAtStartup')
	time = int(config.get('SerraAutoLogin', 'Time'))
	firstRun = config.get('SerraAutoLogin', 'FirstRun') == '1'
	LogManager.log("Config file loaded successfully")
	
	def startTimer():
		global timer		
		
		def timerFunc():
			login(True)
			startTimer()
			
		timer = threading.Timer(time * 60.0, timerFunc)
		timer.daemon = True
		timer.start() 
		LogManager.log("Login Daemon Started")
		
	def stopTimer():
		global timer
		LogManager.log("Old Login Daemon Cancelled")
		timer.cancel()
	
	def find_ip():
		LogManager.log("Searching IP Address...")
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.connect(("gmail.com",80))
		ip = s.getsockname()[0]
		s.close()
		LogManager.log("IP Address found: ("+ip+")")
		return ip
	
	def login(showIcon = True):
		global username
		global password
		global time
		global url
		if showIcon:
			SysTrayIcon.singleton.icon = 'icon/SerraAutoLogin_login.ico'
			SysTrayIcon.singleton.refresh_icon()
		
		LogManager.log("Login function started")
		LogManager.log("NOTICE: This version of the app doesn't work in presence of the 'Remove Old Session' checkbox. Sorry.")
		
		ip = find_ip()
		
		host = re.findall(r"/[a-zA-Z0-9:/._?=&%]*[a-zA-Z0-9:/._?=&%]", url)[0][2:]
		
		headers = {
		"Host": host,
		"User-Agent": "Mozilla/5.0 (Windows NT 6.1; rv:26.0) Gecko/20100101 Firefox/26.0",
		"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
		"Accept-Language": "en,en-us;q=0.8,it-it;q=0.5,it;q=0.3",
		"Accept-Encoding": "gzip, deflate",
		"Connection": "keep-alive"
		}
		r = requests.get(url, headers=headers, verify=False)
		realUrl = re.findall(r"URL=[a-zA-Z0-9:/._?=&%]*[a-zA-Z0-9:/._?=&%]", r.text)[0][4:]
		r = requests.get(realUrl, headers=headers, verify=False)
		postAttr = {
		"reqFrom":"perfigo_login.jsp",
		"uri":url+"/",
		"cm":"ws32vklm",
		"userip":ip,
		"pm":"Win32",
		"index":"4",
		"pageid":"-1",
		"compact":"false",
		"registerGuest":"NO",
		"userNameLabel":"Username",
		"passwordLabel":"Password",
		"guestUserNameLabel":"Guest ID",
		"guestPasswordLabel":"Password",
		"username":username,
		"password":password,
		"provider":"LDAP UniPi"
		}
		p = requests.post("https://"+host+"/auth/perfigo_cm_validate.jsp", postAttr, cookies={"JSESSIONID":r.cookies["JSESSIONID"]}, verify=False)
		status = "LOGGED IN" if len(re.findall(r"Logon Information", p.text)) > 0 else "FAILED LOGIN"
		LogManager.log("Login function ended. Status: "+status)
		
		if showIcon:
			SysTrayIcon.singleton.icon = 'icon/SerraAutoLogin.ico'
			SysTrayIcon.singleton.refresh_icon()
	
	def updateConfig():
		global username
		global password
		global time
		global url
		global loginAtStartup
		LogManager.log("Updating config file...")
		file = open('config.ini', 'w')
		config = configparser.ConfigParser()
		config.add_section('SerraAutoLogin')
		config.set('SerraAutoLogin', 'Username', username)
		config.set('SerraAutoLogin', 'cryptedpassword', Vigenere.encryptMessage("NoobTest", password))
		config.set('SerraAutoLogin', 'Url', url)
		config.set('SerraAutoLogin', 'loginAtStartup', loginAtStartup)
		config.set('SerraAutoLogin', 'Time', str(time))
		config.set('SerraAutoLogin', 'FirstRun', '0')
		config.write(file)
		file.close()
		LogManager.log("Config file updated")
		stopTimer()
		startTimer()

	def changeUsername(sysTrayIcon): 
		global username
		reply = easygui.enterbox(msg='Insert your Serra Username', title='Username', default=username, strip=False)
		if reply:
			username = reply
			updateConfig()
	def changePassword(sysTrayIcon): 
		global password
		reply = easygui.passwordbox(msg='Insert your Serra Password', title='Password', default=password)
		if reply:
			password = reply
			updateConfig()
	def changeUrl(sysTrayIcon): 
		global url
		reply = easygui.enterbox(msg="Insert Serra site URL (without '/' at the end)", title='Serra Site Url', default=url, strip=False)
		if reply:
			url = reply
			updateConfig()
	def changeTime(sysTrayIcon): 
		global time
		reply = easygui.integerbox(msg='Set login interval in minutes', title='Login interval', default=time, lowerbound=30, upperbound=200)
		if reply:
			time = reply
			updateConfig()
	def changeLoginAtStartup(sysTrayIcon):
		global loginAtStartup
		reply = easygui.boolbox(msg='Do you want login at the app startup?', title='Login at Startup', choices=('Yes', 'No'), image=None)
		loginAtStartup = str(reply)
		updateConfig()
	def doLoginNow(sysTrayIcon):
		stopTimer()
		login(sysTrayIcon != None)
		startTimer()
	def showLog(sysTrayIcon):
		easygui.textbox(msg='SerraAutoLogin Log History', title='SerraAutoLogin Log', text=LogManager.readLog(), codebox=0)
	
	def about(sysTrayIcon):
		image = "about.gif"
		msg   = "\t               'SerraAutoLogin'\n\t                   created by\n        Andrea Esposito <info@andreaesposito.org>.\n\n*** If you like my work buy me a cup of coffee, thanks. ***"
		choices = ["Donate","Close"]
		reply=easygui.buttonbox(msg,image=image,choices=choices)
		if reply == "Donate":
			webbrowser.open("https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=and1989%40gmail%2ecom&lc=IT&item_name=Andrea%20Esposito&item_number=SerraAutoLogin&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donate_LG%2egif%3aNonHosted", new=2)
	
	startTimer()
	
	if firstRun:
		LogManager.log("FirstRun procedure starting...")
		changeUsername(None)
		changePassword(None)
		doLoginNow(None)
		LogManager.log("FirstRun procedure Ended")
	else:
		if loginAtStartup == '1':
			doLoginNow(None)
	
	menu_options = (
	('Do Login Now', icon, doLoginNow),
	('Settings', icon, 
		(
		('Set Username', icon, changeUsername),
		('Set Password', icon, changePassword),
		('Set Serra URL', icon, changeUrl),
		('Set Login at Startup', icon, changeLoginAtStartup),
		('Set Login Interval', icon, changeTime)
		)		
	),
	('Show Log', icon, showLog),
	('About', icon, about)
	)
	SysTrayIcon.SysTrayIcon(icon, hover_text, menu_options, default_menu_index=1)
